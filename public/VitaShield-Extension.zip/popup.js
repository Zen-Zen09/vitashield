const avatarMap = {
  boy:    { icon: '👦', cls: 'avatar-boy' },
  girl:   { icon: '👧', cls: 'avatar-girl' },
  secret: { icon: '🌈', cls: 'avatar-secret' }
}

let selectedGender = 'secret'

// ── Chọn giới tính ──
function pickGender(type) {
  selectedGender = type
  document.querySelectorAll('.gender-btn').forEach(e => e.classList.remove('active'))
  document.getElementById('btn-' + type).classList.add('active')
  const hero = document.getElementById('hero-avatar')
  if (hero) {
    hero.textContent = avatarMap[type].icon
    hero.style.animation = 'none'
    setTimeout(() => hero.style.animation = 'bounceIn 0.4s ease', 10)
  }
  chrome.storage.local.set({ gender: type })
}

// Gắn sự kiện click cho các nút giới tính
document.getElementById('btn-boy').addEventListener('click', () => pickGender('boy'))
document.getElementById('btn-secret').addEventListener('click', () => pickGender('secret'))
document.getElementById('btn-girl').addEventListener('click', () => pickGender('girl'))

function showMsg(id, text, isError) {
  const el = document.getElementById(id)
  el.textContent = text
  el.style.color = isError ? '#ef4444' : '#22c55e'
  setTimeout(() => { el.textContent = '' }, 3000)
}

function showPaired(childName, screenTime, gender) {
  document.getElementById('view-unpaired').style.display = 'none'
  document.getElementById('view-paired').style.display = 'block'
  document.getElementById('displayName').textContent = childName || 'Con'
  document.getElementById('screentime').textContent = screenTime || 0
  const g = gender || 'secret'
  const av = document.getElementById('main-avatar')
  av.textContent = avatarMap[g].icon
  av.className = 'avatar-display ' + avatarMap[g].cls
  chrome.storage.local.get(['blockedToday'], r => {
    document.getElementById('blocked-count').textContent = r.blockedToday || 0
  })
}

// ── Kiểm tra trạng thái ──
chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (res) => {
  if (res && res.paired) {
    chrome.storage.local.get(['gender'], r => {
      showPaired(res.childName, res.screenTime, r.gender || 'secret')
    })
  } else {
    document.getElementById('view-unpaired').style.display = 'block'
    document.getElementById('view-paired').style.display = 'none'
    chrome.storage.local.get(['gender'], r => {
      if (r.gender) {
        pickGender(r.gender)
      }
    })
  }
})

// ── Ghép cặp ──
document.getElementById('pairBtn').addEventListener('click', async () => {
  const code = document.getElementById('pairCode').value.trim()
  const childName = document.getElementById('childName').value.trim()

  if (code.length !== 6 || !/^\d+$/.test(code)) {
    showMsg('pair-msg', 'Mã phải là 6 chữ số!', true)
    return
  }
  if (!childName) {
    showMsg('pair-msg', 'Nhập tên con trước nhé! 💜', true)
    return
  }

  const btn = document.getElementById('pairBtn')
  btn.textContent = '⏳ Đang kết nối...'
  btn.disabled = true
  chrome.storage.local.set({ gender: selectedGender })

  chrome.runtime.sendMessage({ type: 'PAIR', code, childName }, (res) => {
    btn.textContent = '🔗 Ghép cặp ngay'
    btn.disabled = false
    if (res && res.ok) {
      showPaired(childName, 0, selectedGender)
    } else {
      showMsg('pair-msg', res?.error || 'Mã không đúng, thử lại nhé!', true)
    }
  })
})

// ── Hủy ghép cặp ──
document.getElementById('unpairBtn').addEventListener('click', () => {
  if (!confirm('Hủy ghép cặp? Extension sẽ ngừng bảo vệ.')) return
  chrome.runtime.sendMessage({ type: 'UNPAIR' }, () => {
    document.getElementById('view-unpaired').style.display = 'block'
    document.getElementById('view-paired').style.display = 'none'
    document.getElementById('pairCode').value = ''
    document.getElementById('childName').value = ''
  })
})