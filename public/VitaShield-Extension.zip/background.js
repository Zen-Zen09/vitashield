const PROJECT_ID = 'vitashield-74999'
const BASE_URL = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents`

const BLACKLIST = [
  'pornhub.com','xvideos.com','xnxx.com','xhamster.com',
  'redtube.com','youporn.com','tube8.com','spankbang.com',
  '1xbet.com','bet365.com','w88.com','fb88.com','88vin.com',
  'ma-tuy.com','drugs.com','heroin.net'
]

const aiCache = {}

async function loadConfig() {
  return new Promise(resolve => {
    chrome.storage.local.get([
      'parentId', 'deviceId', 'childName', 'filterEnabled',
      'youtubeWhitelist', 'remoteBlockedUrls', 'parentEmail'
    ], resolve)
  })
}

async function firestoreQuery(collectionId, fieldPath, value) {
  const res = await fetch(`${BASE_URL}:runQuery`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      structuredQuery: {
        from: [{ collectionId }],
        where: { fieldFilter: { field: { fieldPath }, op: 'EQUAL', value: { stringValue: value } } },
        limit: 1
      }
    })
  })
  return res.json()
}

async function fetchAndSyncSettings(parentId) {
  try {
    const res = await fetch(`${BASE_URL}/parents/${parentId}`)
    const data = await res.json()
    if (!data.fields) return null

    const settings = {
      remoteBlockedUrls: data.fields.blockedUrls?.arrayValue?.values?.map(v => v.stringValue) || [],
      filterEnabled: data.fields.filterEnabled?.booleanValue ?? true,
      youtubeWhitelist: data.fields.youtubeWhitelist?.arrayValue?.values?.map(v => v.stringValue) || [],
      screenTimeLimit: parseInt(data.fields.screenTimeLimit?.integerValue) || 120,
      parentEmail: data.fields.email?.stringValue || ''
    }

    chrome.storage.local.set(settings)
    return settings
  } catch { return null }
}

async function logToFirestore(parentId, deviceId, hostname, blocked, reason) {
  try {
    await fetch(`${BASE_URL}/logs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fields: {
          parentId: { stringValue: parentId },
          deviceId: { stringValue: deviceId },
          url: { stringValue: hostname },
          blocked: { booleanValue: blocked },
          reason: { stringValue: reason || '' },
          time: { stringValue: new Date().toISOString() }
        }
      })
    })
  } catch {}
}

async function updateScreenTime(parentId, deviceId, minutes) {
  try {
    await fetch(`${BASE_URL}/devices/${deviceId}?updateMask.fieldPaths=screenTime&updateMask.fieldPaths=online`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fields: {
          screenTime: { integerValue: minutes },
          online: { booleanValue: true }
        }
      })
    })
  } catch {}
}

async function sendEmailNotification(parentEmail, childName, hostname) {
  if (!parentEmail) return
  try {
    await fetch('https://vitashield.vercel.app/api/notify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        to_email: parentEmail,
        parent_name: 'Phu huynh',
        child_name: childName || 'Con',
        blocked_url: hostname,
        device_name: 'Chrome Extension'
      })
    })
    console.log('[VitaShield] Email sent to:', parentEmail)
  } catch (e) {
    console.error('[VitaShield] Email error:', e.message)
  }
}

async function analyzeWithAI(hostname, title, text) {
  const cacheKey = `${hostname}||${title || ''}`.slice(0, 100)
  if (aiCache[cacheKey] !== undefined) return aiCache[cacheKey]

  try {
    const isVideo = hostname.includes('youtube.com') || hostname.includes('tiktok.com')
    const prompt = isVideo
      ? `Tieu de video: "${title || ''}"\nNguon: ${hostname}`
      : `Website: ${hostname}\nTieu de: "${title || ''}"\nNoi dung: "${text?.slice(0, 300) || ''}"`

    const res = await fetch('https://vitashield.vercel.app/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        mode: 'filter',
        messages: [{ role: 'user', content: prompt }]
      })
    })
    const data = await res.json()
    const isSafe = !data.result?.trim().toUpperCase().includes('BLOCK')
    aiCache[cacheKey] = isSafe
    return isSafe
  } catch { return true }
}

function blockTab(tabId, url, reason) {
  chrome.tabs.update(tabId, {
    url: chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(url) + '&reason=' + (reason || '')
  })
}

chrome.alarms.create('screenTime', { periodInMinutes: 1 })
chrome.alarms.create('syncSettings', { periodInMinutes: 2 })

chrome.alarms.onAlarm.addListener(async (alarm) => {
  const config = await loadConfig()
  if (!config.parentId || !config.deviceId) return

  if (alarm.name === 'screenTime') {
    const r = await new Promise(resolve => chrome.storage.local.get(['screenTime'], resolve))
    const newTime = (r.screenTime || 0) + 1
    chrome.storage.local.set({ screenTime: newTime })
    await updateScreenTime(config.parentId, config.deviceId, newTime)
  }

  if (alarm.name === 'syncSettings') {
    await fetchAndSyncSettings(config.parentId)
  }
})

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'loading' || !tab.url) return
  if (!tab.url.startsWith('http')) return

  const config = await loadConfig()
  if (!config.parentId || !config.deviceId) return

  const freshSettings = await fetchAndSyncSettings(config.parentId)
  const blockedUrls = freshSettings?.remoteBlockedUrls || config.remoteBlockedUrls || []
  const filterEnabled = freshSettings?.filterEnabled ?? config.filterEnabled ?? true
  const parentEmail = freshSettings?.parentEmail || config.parentEmail || ''

  try {
    const url = tab.url
    const hostname = new URL(url).hostname.replace('www.', '')

    console.log('[VitaShield] Check:', hostname, '| blockedUrls:', blockedUrls)

    if (BLACKLIST.some(b => hostname.includes(b))) {
      await logToFirestore(config.parentId, config.deviceId, hostname, true, 'blacklist')
      await sendEmailNotification(parentEmail, config.childName, hostname)
      blockTab(tabId, url, 'blacklist')
      return
    }

    if (blockedUrls.length > 0 && blockedUrls.some(b => b && hostname.includes(b))) {
      console.log('[VitaShield] BLOCKED manual:', hostname)
      await logToFirestore(config.parentId, config.deviceId, hostname, true, 'manual')
      await sendEmailNotification(parentEmail, config.childName, hostname)
      blockTab(tabId, url, 'manual')
      return
    }

    if ((hostname.includes('youtube.com') || hostname.includes('youtu.be')) && url.includes('/watch')) {
      const whitelist = freshSettings?.youtubeWhitelist || config.youtubeWhitelist || []
      if (whitelist.length > 0 && !whitelist.some(ch => url.includes(ch))) {
        await logToFirestore(config.parentId, config.deviceId, hostname, true, 'youtube-whitelist')
        blockTab(tabId, url, 'youtube')
        return
      }
    }

    if (filterEnabled) {
      const safe = await analyzeWithAI(hostname, null, null)
      if (!safe) {
        await logToFirestore(config.parentId, config.deviceId, hostname, true, 'ai-domain')
        await sendEmailNotification(parentEmail, config.childName, hostname)
        blockTab(tabId, url, 'ai')
        return
      }
    }

    await logToFirestore(config.parentId, config.deviceId, hostname, false, 'safe')
  } catch (e) {
    console.error('[VitaShield] Tab error:', e.message)
  }
})

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'ANALYZE_CONTENT') {
    const { hostname, title, text, url } = msg
    loadConfig().then(async config => {
      if (!config.parentId || !config.deviceId) return
      const filterEnabled = config.filterEnabled ?? true
      if (!filterEnabled) return

      const safe = await analyzeWithAI(hostname, title, text)
      if (!safe) {
        await logToFirestore(config.parentId, config.deviceId, hostname, true, 'ai-content')
        await sendEmailNotification(config.parentEmail, config.childName, hostname)
        chrome.tabs.update(sender.tab.id, {
          url: chrome.runtime.getURL('blocked.html') + '?url=' + encodeURIComponent(url) + '&reason=content'
        })
      }
    })
    return false
  }

  if (msg.type === 'GET_STATUS') {
    loadConfig().then(config => {
      chrome.storage.local.get(['screenTime'], r => {
        sendResponse({
          paired: !!(config.parentId && config.deviceId),
          childName: config.childName,
          screenTime: r.screenTime || 0
        })
      })
    })
    return true
  }

  if (msg.type === 'PAIR') {
    pairDevice(msg.code, msg.childName).then(result => sendResponse(result))
    return true
  }

  if (msg.type === 'UNPAIR') {
    chrome.storage.local.clear(() => sendResponse({ ok: true }))
    return true
  }
})

async function pairDevice(code, childName) {
  try {
    console.log('[VitaShield] Pairing code:', code)

    let parentId = null
    const newResults = await firestoreQuery('pairingCodes', 'code', code)
    const codeDoc = newResults[0]?.document

    if (codeDoc) {
      const expiresAt = codeDoc.fields?.expiresAt?.stringValue
      if (expiresAt && new Date(expiresAt) < new Date()) {
        return { ok: false, error: 'Ma da het han, vui long tao ma moi' }
      }
      if (codeDoc.fields?.used?.booleanValue) {
        return { ok: false, error: 'Ma da duoc su dung' }
      }
      parentId = codeDoc.fields?.parentId?.stringValue
      const docId = codeDoc.name.split('/').pop()
      await fetch(`${BASE_URL}/pairingCodes/${docId}?updateMask.fieldPaths=used`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fields: { used: { booleanValue: true } } })
      })
    } else {
      const oldResults = await firestoreQuery('parents', 'pairingCode', code)
      const oldDoc = oldResults[0]?.document
      if (!oldDoc) return { ok: false, error: 'Ma khong hop le' }
      parentId = oldDoc.name.split('/').pop()
    }

    const deviceId = 'device_' + Date.now()

    await fetch(`${BASE_URL}/devices/${deviceId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fields: {
          parentId: { stringValue: parentId },
          childName: { stringValue: childName || 'Con' },
          pairedAt: { stringValue: new Date().toISOString() },
          online: { booleanValue: true },
          screenTime: { integerValue: 0 }
        }
      })
    })

    chrome.storage.local.set({ parentId, deviceId, childName: childName || 'Con', screenTime: 0 })

    const settings = await fetchAndSyncSettings(parentId)
    console.log('[VitaShield] Settings after pairing:', JSON.stringify(settings))
    console.log('[VitaShield] Paired! parentId:', parentId)
    return { ok: true, parentId, deviceId }
  } catch (e) {
    console.error('[VitaShield] pairDevice error:', e.message)
    return { ok: false, error: e.message }
  }
}