const params = new URLSearchParams(location.search)
const url = params.get('url') || 'Trang không xác định'
document.getElementById('blocked-url').textContent = url
document.getElementById('backBtn').addEventListener('click', () => {
  history.back()
})