const DANGEROUS_KEYWORDS = [
  'khiêu dâm', 'sex', 'porn', 'nude', 'xxx',
  'ma túy', 'heroin', 'cocaine', 'cần sa',
  'tự tử', 'tự làm hại', 'cắt tay',
  'cờ bạc', 'cá cược', 'đánh bài'
]

const hostname = location.hostname.replace('www.', '')
const isYoutube = hostname.includes('youtube.com') || hostname.includes('youtu.be')
const isTiktok = hostname.includes('tiktok.com')

// ── Lấy tiêu đề video YouTube ──
function getYoutubeTitle() {
  // Thử nhiều selector vì YouTube hay thay đổi DOM
  const selectors = [
    'h1.ytd-video-primary-info-renderer yt-formatted-string',
    'h1.ytd-watch-metadata yt-formatted-string',
    '#title h1 yt-formatted-string',
    'ytd-watch-metadata h1',
    'h1.title'
  ]
  for (const sel of selectors) {
    const el = document.querySelector(sel)
    if (el?.textContent?.trim()) return el.textContent.trim()
  }
  return document.title?.replace(' - YouTube', '').trim() || ''
}

// ── Lấy tiêu đề video TikTok ──
function getTiktokTitle() {
  const selectors = [
    'h1[data-e2e="browse-video-desc"]',
    'span[data-e2e="browse-video-desc"]',
    'div[data-e2e="video-desc"]',
    '.video-meta-title',
    'h1'
  ]
  for (const sel of selectors) {
    const el = document.querySelector(sel)
    if (el?.textContent?.trim()) return el.textContent.trim()
  }
  return document.title?.replace(' | TikTok', '').trim() || ''
}

// ── Phân tích nội dung trang thường ──
function checkPageContent() {
  const text = document.body?.innerText?.toLowerCase() || ''
  const found = DANGEROUS_KEYWORDS.filter(kw => text.includes(kw))
  if (found.length >= 2) {
    chrome.runtime.sendMessage({
      type: 'ANALYZE_CONTENT',
      hostname,
      title: document.title,
      text: document.body?.innerText?.slice(0, 500),
      url: location.href
    })
  }
}

// ── Phân tích video YouTube ──
function analyzeYoutubeVideo() {
  if (!location.pathname.includes('/watch')) return

  const title = getYoutubeTitle()
  if (!title) {
    // Title chưa load, thử lại sau
    setTimeout(analyzeYoutubeVideo, 2000)
    return
  }

  console.log('[VitaShield] YouTube title:', title)
  chrome.runtime.sendMessage({
    type: 'ANALYZE_CONTENT',
    hostname,
    title,
    text: '',
    url: location.href
  })
}

// ── Phân tích video TikTok ──
function analyzeTiktokVideo() {
  const title = getTiktokTitle()
  if (!title) {
    setTimeout(analyzeTiktokVideo, 2000)
    return
  }

  console.log('[VitaShield] TikTok title:', title)
  chrome.runtime.sendMessage({
    type: 'ANALYZE_CONTENT',
    hostname,
    title,
    text: '',
    url: location.href
  })
}

// ── Theo dõi thay đổi URL (YouTube/TikTok là SPA) ──
let lastUrl = location.href
const observer = new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href
    if (isYoutube) setTimeout(analyzeYoutubeVideo, 1500)
    if (isTiktok) setTimeout(analyzeTiktokVideo, 1500)
  }
})
observer.observe(document.body, { subtree: true, childList: true })

// ── Chạy khi trang load ──
function init() {
  if (isYoutube) {
    analyzeYoutubeVideo()
  } else if (isTiktok) {
    analyzeTiktokVideo()
  } else {
    checkPageContent()
  }
}

if (document.readyState === 'complete') {
  init()
} else {
  window.addEventListener('load', init)
}